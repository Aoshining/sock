源代码文件目录下终端输入 make / mingw32-make 完成编译
./Fraction 运行可执行文件
输入两个小数或分数，以空格分隔
测试样例：

input：
-1.25 4/5

output：
f1 + f2 = -9/20   (-0.450000)
f1 - f2 = -41/20  (-2.050000)
f1 * f2 = -1/1    (-1.000000)
f1 / f2 = -25/16  (-1.562500)
f1 <  f2 : True
f1 <= f2 : True
f1 == f2 : False
f1 != f2 : True
f1 >= f2 : False
f1 >  f2 : False