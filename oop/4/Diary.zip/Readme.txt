进入当前文件夹，终端输入.\run.cmd执行脚本以完成下列操作样例：

mingw32-make

.\pdadd
20231111
Let's go shopping!

.\pdlist

.\pdlist 20231030 20231111

.\pdshow

.\pdremove 20231111

.\pdshow 20231111