#include "diary.h"
using namespace std;

int main()
{
	Diary d;
	d.pdadd();
	return 0;
}