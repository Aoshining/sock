Use vscode to open cx2023_3220105775_P1.c, click "Run code" in the upper right corner to run the program.

Note: The macro definition N at the beginning of the code can be modified to change the matrix side lengths, K1 to change the number of iterations of Algorithm 1, K2 to change the number of iterations of Algorithm 2, and K3 to change the number of iterations of Algorithm 3.